﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CarManufacturer
{
    public class Car
    {
		private string model;
		private string make;
        private string year;
        
        public string Model { get; set; }
        public string Make { get; set; }
        public int Year { get; set; }
    }

}

//Define in the above class private fields for:
// make: string
// model: string
// year: int
//The class should also have public properties for:
// Make: string
// Model: string
// Year: int