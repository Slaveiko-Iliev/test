﻿namespace BookShop;

using Data;
using System;
using Initializer;
using System.Text;

public class StartUp
{
    public static void Main()
    {
        using var db = new BookShopContext();
        //DbInitializer.ResetDatabase(db);

        string command = Console.ReadLine();

        Console.WriteLine(GetBooksByAgeRestriction(db, command));
    }

    public static string GetBooksByAgeRestriction(BookShopContext context, string command)
    {
        var books = context.Books
            .OrderBy(b => b.Title)
            .ToArray();

        StringBuilder sb = new StringBuilder();

        foreach (var book in books)
        {
            if (book.AgeRestriction.ToString().ToLower() == command.ToLower())
            {
                sb.AppendLine(book.Title);
            }

        }

        return sb.ToString().TrimEnd();
    }

}




