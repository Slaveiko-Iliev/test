﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=CarDealer;Integrated Security=True;Encrypt=False";
    }
}
