﻿namespace Shapes
{
    internal interface IDrawable
    {
        public void Draw();
    }
}
