﻿namespace _08.CollectionHierarchy.Models.Interfaces
{
    public interface IAddable
    {
        public int Add(string str);
    }
}
