﻿namespace _08.CollectionHierarchy.Models.Interfaces
{
    public interface IAddRemoveWithUsed : IAddRemovable
    {
        public int Used { get;}
    }
}
