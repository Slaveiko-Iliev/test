﻿namespace _03.Telephony
{
    public interface ICallingable
    {
        public string Calling(string phoneNumber);
    }
}
