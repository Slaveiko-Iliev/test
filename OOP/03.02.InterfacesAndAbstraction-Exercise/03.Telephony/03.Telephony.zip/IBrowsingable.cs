﻿namespace _03.Telephony
{
    public interface IBrowsingable
    {
        public string Browsing(string adres);
    }
}
