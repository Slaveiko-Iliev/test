﻿namespace _05.FootballTeamGenerator.Models
{
    public class ExceptionMessage
    {
        public const string EmptyName = "A name should not be empty.";
    }
}
