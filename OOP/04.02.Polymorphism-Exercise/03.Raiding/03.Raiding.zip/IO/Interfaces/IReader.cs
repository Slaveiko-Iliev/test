﻿namespace _03.Raiding.IO.Interfaces;

public interface IReader
{
    string ReadLine();
}
