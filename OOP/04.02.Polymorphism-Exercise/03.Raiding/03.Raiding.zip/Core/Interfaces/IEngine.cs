﻿namespace _03.Raiding.Core.Interfaces;

public interface IEngine
{
    void Run();
}
