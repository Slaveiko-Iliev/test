﻿namespace _04.WildFarm.Core.Interfaces;

public interface IEngine
{
    void Run();
}
