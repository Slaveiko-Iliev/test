﻿namespace _04.WildFarm.Models.Interfaces
{
    public interface IFood
    {
        int Quantity { get; }
    }
}
