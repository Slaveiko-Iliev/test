﻿namespace _04.WildFarm.Models.Interfaces
{
    public interface Ibird : IAnimal
    {
        double WingSize { get; }
    }
}
