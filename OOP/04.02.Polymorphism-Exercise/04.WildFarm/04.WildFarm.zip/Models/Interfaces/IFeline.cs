﻿namespace _04.WildFarm.Models.Interfaces
{
    public interface IFeline
    {
        string Breed { get; }
    }
}
