﻿namespace _04.WildFarm.IO.Interfaces;

public interface IReader
{
    string ReadLine();
}
