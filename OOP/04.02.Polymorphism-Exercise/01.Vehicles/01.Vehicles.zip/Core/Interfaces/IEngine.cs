﻿namespace _01.Vehicles.Core.Interfaces
{
    public interface IEngine
    {
        public void Run();
    }
}
