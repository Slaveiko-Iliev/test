﻿

namespace NeedForSpeed
{
    public class Vehicle
    {
		private int _hordePower;
		private double _fuel;

        public Vehicle(int horsePower, double fuel)
        {
            HorsePower = horsePower;
            Fuel = fuel;
        }

        public int HorsePower
		{
			get { return _hordePower; }
			set { _hordePower = value; }
		}
        public double Fuel
        {
            get { return _fuel; }
            set { _fuel = value; }
        }
        public double DefaultFuelConsumption { get { return 1.25; }}
        public virtual double FuelConsumption { get; set; }

        public virtual void Drive(double kilometers)
        {
            FuelConsumption = this.DefaultFuelConsumption * kilometers;
            Fuel -= FuelConsumption;
        }
    }
}

